
public class Knowledge {

	public static void main(String[] args) {
		System.out.println("Knowledge is Power");
		System.out.println();
		System.out.println("Knowledge");
		System.out.println("   is");
		System.out.println("  power");
		System.out.println();
		System.out.println("======================");
		System.out.println("|                    |");
		System.out.println("| Knowledge is Power |");
		System.out.println("|                    |");
		System.out.println("======================");
	}

}
