package lab1_hguo5;
	//************************************************************
	//Lab1.java       Author: Hu Guo
	//CSC140 	
	//print a sentence in a specific form
	//************************************************************

public class lab1_hguo5 {
	
	public static void main(String[] args) {
		//output method
		System.out.println("");
		System.out.println("   |===========|");
		System.out.println("   | Knowledge |");
		System.out.println("   |    is     |");
		System.out.println("   |   power   |");
		System.out.println("   |===========|");
	}
	
}