import java.text.DecimalFormat;

public class Postal 
{
	// Class fields
	private String firstName = "";
	private String lastName = "";
	private int zipCode;
	private static DecimalFormat fmt;


	// Class methods
	// Constructor
	public Postal(String fName, String lName, int zCode) 
	{
		firstName = fName;
		lastName = lName;
		zipCode = zCode;
		fmt = new DecimalFormat("00000");
	}

	// Getters and setters
	public String getFName() 
	{
		return firstName;
	}

	public String getLName() 
	{
		return lastName;
	}

	public int getZCode() 
	{
		return zipCode;
	}

	// Returns a string description of this object in a one line format
	public String toString() 
	{
		return firstName + " " + lastName + "\t" + fmt.format(zipCode);
	}
}
