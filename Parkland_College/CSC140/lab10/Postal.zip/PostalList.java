import java.util.Scanner;

public class PostalList 
{
	// Constant - maximum size of array
	public static final int MAX = 25;

	public static void main(String[] args)
	{
		// Create array of Postal objects
		Postal[] contacts = new Postal[MAX];
		
		// Array index counter
		int count = 0;
		
		// Create Scanner object to read input
		Scanner scan = new Scanner(System.in);
		
		// Indicates complete
		boolean done = false;
		
		// Prompt user to enter information
		while(!done)
		{
			System.out.print("Enter firstname lastname zip-code: ");
			
			// Store information
			String firstName = scan.next();
			String lastName = scan.next();
			int zipCode = scan.nextInt();
			
			// Create Postal object and store in array
			contacts[count] = new Postal(firstName, lastName, zipCode);
			
			// Increment array counter
			count++;
			
			// Prompt to continue or quit
			System.out.print("Continue? (y/n): ");
			String result = scan.next();
			if( result.equals("n"))
				done = true;
		}
		
		// Print the list of Postal objects
		System.out.println("\nTotal number of Postal objects: " + count);
		for(int i = 0; i < count; i++)
			System.out.println(contacts[i]);	
	}
}