package Lab10_hguo5;

import java.util.Scanner;

public class PostalList 
{

	public static void main(String[] args) 
	{	
		//Declaration and Initialization
		final int MAX = 10; //array size
		
		int index = 0; //Iterator
		
		String choice = "y";
		
		String firstName = "", lastName = "";
		int zipCode = 0;
		
		Scanner scan = new Scanner (System.in);
		
		//Create an Array of the Postal Class
		Postal [] postal = new Postal [MAX];
				
		//Loop to continue the program
		do
		{
			//Prompt for name and zip-code
			System.out.print("Enter firstname lastname zip-code: ");
			firstName = scan.next();
			lastName = scan.next();
			zipCode = scan.nextInt();
			scan.nextLine();
			System.out.println ();
					
			//To use the constructor instantiate the object
			postal[index] = new Postal(firstName, lastName, zipCode);
			
			//Prompt for continuing or not
			System.out.print ("Continue? (y/n): ");
			choice = scan.next();	
			scan.nextLine();
			System.out.println ();
			
			//Iterator increase one
			index++;	
									
		}while(choice.equalsIgnoreCase("y") && index < MAX);
			
		//Prompt for maximum size
		if( index == MAX)
		{
			System.out.println("\n" + "Sorry, the postal list have reached maximum size.");
		}
		
		//Prompt for the number of objects in the array
		System.out.println("\n" + "Total number of Postal objects: " + Postal.getCount() + "\n");
		
		for(index = 0; index < Postal.getCount(); index++)
		{
			System.out.println(postal[index]);
		}	
		
		//Close the scan object
		scan.close();
		
		System.out.println("Program terminated.");
	}

}
