package Lab10_hguo5;

import java.text.DecimalFormat;

public class Postal 
{	
	//Declaration and Initialization
	private String firstName, lastName; 
	private int zipCode = 0;
	
	//Static variable to count objects
	private static int count = 0;
	
	//Constructor
	public Postal(String firstName, String lastName, int zipCode)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.zipCode = zipCode;
		count++;
	}
	
	//Getters
	public String getFirstName() 
	{
		return firstName;
	}
	
	public String getLastName() 
	{
		return lastName;
	}
	
	public String getZipCode() 
	{	
		DecimalFormat fmt = new DecimalFormat("00000");
		return fmt.format(this.zipCode);
	}
	
	//Static method to get objects' number
	public static int getCount() 
	{
		return count;
	}
	
	//Setter for the first name
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}

	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}

	public void setZipCode(int zipCode) 
	{
		this.zipCode = zipCode;
	}
	
	//ToString method
	public String toString()
	{
		String result;
		result = this.getFirstName() + " " + this.getLastName() + "\t";
		result +="\t" + this.getZipCode();
		return result;
	}
	
}
