public class MonetaryCoin extends Coin {
	
	// Knows about a value
	private int value;

	// Sets up a coin with a value
	public MonetaryCoin(int money) {
		super();
		value = money;
	}

	// Getter/setter
	public int getValue() {
		return value;
	}
	public void setValue(int money) {
		value = money;
	}

	// Override parent toString method
	@Override
	public String toString() {
		String result = super.toString();
		result += "\t" + value;
		return result;
	}
}
