public class MonetaryCoinDriver {
	
	public static void main(String[] args) {
		
		// An array of monetary coins
		MonetaryCoin[] coins = new MonetaryCoin[7];
		coins[0] = new MonetaryCoin(1);
		coins[1] = new MonetaryCoin(5);
		coins[2] = new MonetaryCoin(10);
		coins[3] = new MonetaryCoin(25);
		coins[4] = new MonetaryCoin(50);
		coins[5] = new MonetaryCoin(100);
		coins[6] = new MonetaryCoin(100);

		// Compute total value of all coins
		int sum = 0;
		for(MonetaryCoin coin : coins)
			sum += coin.getValue();

		// Print the coins
		for (MonetaryCoin coin : coins)
			System.out.println(coin);

		// Print total value
		System.out.println("\nTotal Value: " + sum);
		
		// Demonstrate inherited method to flip
		// by flipping first coin (penny) 5 times
		System.out.println();
		for(int i = 0; i < 5; ++i)
		{
			System.out.print("coin flip " + i + ": ");
			coins[0].flip();
			System.out.println(coins[0]);
		}
	}
}
