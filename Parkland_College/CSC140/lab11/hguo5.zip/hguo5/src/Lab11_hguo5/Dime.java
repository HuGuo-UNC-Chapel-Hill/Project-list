package Lab11_hguo5;

public class Dime extends MonetaryCoin 
{	
	//Constructor
	public Dime()
	{
		value = 10;
		super.flip();
	}				
}
