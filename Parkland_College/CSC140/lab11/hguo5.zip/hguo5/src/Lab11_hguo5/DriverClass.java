package Lab11_hguo5;

public class DriverClass 
{
	public static void main(String[] args)
	{	
		//Declaration and Initialization
		int sum = 0;
		
		//Create the object of Penny class
		Penny penny1 = new Penny();
		System.out.println("You flip a penny, " + penny1);
		
		//Create the object of Nickel class
		Nickel nickel1 = new Nickel();
		System.out.println("You flip a nickle, " + nickel1);
		
		//Create the object of Dime class
		Dime dime1 = new Dime();
		System.out.println("You flip a dime, " +  dime1);
		
		//Create an array of MonetaryCoin Class
		//and add different objects of different coin classes to the array
		MonetaryCoin[] coins ={ new Penny(), new Penny(), new Penny(),
												 new Nickel(), new Nickel(),
												 new Dime()};
		
		//for loop to calculate the sum of different coins
		for(MonetaryCoin coin: coins)
		{
			sum +=coin.getValue();
		}
		
		//output the sum 
		System.out.println("There are three pennies, two nickels, and one dime in your pocket, "
										+ "and the total value is " 
										+ MonetaryCoin.fm.format(sum*MonetaryCoin.CENTSRATE) 
										+".\n");
		System.out.println("Program terminated.");
	}
	
}
