package Lab11_hguo5;

public class Nickel extends MonetaryCoin
{
	//Constructor
	public Nickel()
	{
		value = 5;
		super.flip();
	}				
}
