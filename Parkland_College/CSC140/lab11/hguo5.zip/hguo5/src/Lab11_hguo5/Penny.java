package Lab11_hguo5;

public class Penny extends MonetaryCoin
{	
	//Constructor
	public Penny()
	{
		value = 1;
		super.flip();
	}					
}
