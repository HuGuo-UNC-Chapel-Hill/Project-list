package Lab11_hguo5;

public class Dime extends MonetaryCoin 
{	
	//Constructor
	public Dime()
	{	
		super();//invoke the constructor from parent class
		this.value = 10;
	}
}
