package Lab11_hguo5;

import java.text.NumberFormat;

public class MonetaryCoin 
{ 
	//Declaration and Initialization
	private final int HEADS = 0;
	private final int TAILS = 1;
	private int face;
	private String faceName;
	
	protected int value = 0;
	
	//static variable 
	public final static double CENTSRATE = 0.01; 
	public static NumberFormat fm = NumberFormat.getCurrencyInstance();
	
	//Constructor
	public MonetaryCoin ()
	{
		flip();
	}
	
	public void flip()
	{
		face = (int) (Math.random()*2);
	}
	
	public boolean isHeads ()
	{
		return (face == HEADS);
	}
	
	public int getValue()
	{
		return value;
	}
	
	public String toString()
	{
		String faceName, result;
		if (face == HEADS)
			faceName = "HEADS";
		else
			faceName = "Tails";
		result = faceName;
		result += "\n"+"The value of this coin is ";
		result +=fm.format(this.value*CENTSRATE) +".\n";		
		return result;
	}
}


