package Lab11_hguo5;

public class Nickel extends MonetaryCoin
{
	//Constructor
	public Nickel()
	{
		super();//invoke the constructor from parent class
		this.value = 5;
	}	
	
}
