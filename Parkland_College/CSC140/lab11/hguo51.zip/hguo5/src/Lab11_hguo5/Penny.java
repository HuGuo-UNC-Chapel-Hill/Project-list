package Lab11_hguo5;

public class Penny extends MonetaryCoin
{	
	//Constructor
	public Penny()
	{
		super();//invoke the constructor from parent class
		this.value = 1;
	}	
	
}
