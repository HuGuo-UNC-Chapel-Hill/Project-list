package Lab11_hguo5;

import java.text.NumberFormat;

public class MonetaryCoin 
{ 
	//Declaration and Initialization
	private final int HEADS = 0;
	private final int TAILS = 1;
	private int face;
	
	private int value = 0;
	
	//static variable 
	public final static double CENTSRATE = 0.01; 
	public static NumberFormat fm = NumberFormat.getCurrencyInstance();
	
	//Constructor
	public MonetaryCoin ()
	{
		flip();
	}
	
	//Overloading the constructor
	public MonetaryCoin (int value)
	{
		flip();
		this.value = value;
	}
	
	public void flip()
	{
		face = (int) (Math.random()*2);
	}
	
	public boolean isHeads ()
	{
		return (face == HEADS);
	}
	
	public int getValue()
	{
		return value;
	}
	
	public String toString()
	{
		String faceName;
		if (face == HEADS)
			faceName = "HEADS";
		else
			faceName = "Tails";
		return faceName;	
	}
}


