package Lab11_hguo5;

public class Nickel extends MonetaryCoin
{
	//Constructor
	public Nickel()
	{
		super(5);//invoke the constructor from parent class
	}	
	
	//Overriding toString method
	public String toString()
	{
		String result;
		result = super.toString();
		result += "\n"+"The value of this coin is ";
		result +=fm.format(this.getValue()*CENTSRATE) +".\n";		
		return result;
	}
}
