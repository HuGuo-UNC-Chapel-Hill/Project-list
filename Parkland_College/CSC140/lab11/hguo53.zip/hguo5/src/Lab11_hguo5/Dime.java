package Lab11_hguo5;

public class Dime extends MonetaryCoin 
{	
	//Constructor
	public Dime()
	{	
		super(10);//invoke the constructor from parent class
	}
	
	//Overriding toString method
	public String toString()
	{
		String result;
		result = super.toString();
		result += "\n"+"The value of this coin is ";
		result +=fm.format(value*CENTSRATE) +".\n";		
		return result;
	}
}
