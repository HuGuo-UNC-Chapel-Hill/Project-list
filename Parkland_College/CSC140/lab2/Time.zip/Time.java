import java.util.Scanner;

public class Time {

	public static void main(String[] args) {

		// Prompt user
		System.out.print("Enter time in seconds: ");
		
		// Get input from user
		Scanner scan = new Scanner(System.in);
		int input = scan.nextInt();
		
		// Compute hours
		int hours = input / 3600;
		
		// Seconds remaining
		int remainder = input % 3600;
		
		// Compute minutes
		int minutes = remainder / 60;
		
		// Compute seconds
		int seconds = remainder % 60;
		
		// Print result
		System.out.println(hours + " hours");
		System.out.println(minutes + " minutes");
		System.out.println(seconds + " seconds");
	}

}
