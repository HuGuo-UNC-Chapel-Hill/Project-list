import java.text.DecimalFormat;
import java.util.Random;


public class PhoneNumber {

	public static void main(String[] args) {
	
		// Random number generator
		Random random = new Random();
		
		// First three numbers with digits not containing 8 or 9
		int n1_1 = random.nextInt(8);
		int n1_2 = random.nextInt(8);
		int n1_3 = random.nextInt(8);
		
		// Second set of three digits not greater than 742
		DecimalFormat df1 = new DecimalFormat("000");
		int n2 = random.nextInt(743);
		
		// Third set of four digits
		DecimalFormat df2 = new DecimalFormat("0000");
		int n3 = random.nextInt(10000);
	
		// Print result
		System.out.println(n1_1 + "" + n1_2 + "" + n1_3 + "-" + df1.format(n2) + "-" + df2.format(n3));
	}
}
