package lab3_hguo5;
	//************************************************************
	//CSC140 Lab3.java       Author: Hu Guo
	//Generate random phone numbers.
	//************************************************************

//import necessary classes
import java.util.Random;
import java.util.Scanner;
import java.text.DecimalFormat;

public final class lab3_hguo5 
{

	public static void main(String[] args) 
	{
		//Declaration and Initialization Variables	
		Random generator = new Random();
		 
		DecimalFormat mid_FMT = new DecimalFormat("000");
		 
		DecimalFormat las_FMT = new DecimalFormat("0000");
		 		 
		int fri_SET = 0, mid_SET = 0, las_SET = 0;
		 
		char choice = 'y';
		 
		String input="";
		 
		Scanner scan = new Scanner(System.in);
		 
		//Loop to Continue Running the Program
		do
		{
			//Generate the random phone number
			fri_SET = (generator.nextInt(7)+1)*100;
		 
			fri_SET += generator.nextInt(8)*10;
		 
			fri_SET += generator.nextInt(8);		 
		 
			mid_SET= generator.nextInt(743);
		 
			las_SET= generator.nextInt(10000);
			 
			//Output the phone number
			System.out.print("\n The generated phone number is: "+		 
	 				  		fri_SET+"-"+mid_FMT.format(mid_SET)
	 				  		+"-"+las_FMT.format(las_SET)+"\n");
			 
			//Prompt for Choices to Continue or End the Program
			System.out.print("\n Please input (Y) to continue or (N) to quit: ");
				
			//Get the Sting from User's Input
			input = scan.nextLine();
				
			//Get the First Letter as the Value of the Choice
			choice = input.charAt(0);
					
			//Advance to a New line
			System.out.println("");
			 
		}while(choice == 'y' || choice == 'Y');
		 
		//Close the scanner object
		scan.close();
		 
		//Prompt for End of the Program
		System.out.print("Program terminated.");		 
	}
}
