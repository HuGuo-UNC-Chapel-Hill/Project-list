
import java.util.Scanner;

public class CountDigits {

	public static void main(String[] args) 
	{
		int oddCount = 0, evenCount = 0, zeroCount = 0;
		int value, digit;

		// Prompt user for an integer
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter an integer value: ");
		value = scan.nextInt();

		// Take absolute value to assure positive value
		value = Math.abs(value);

		// Zero value
		if (value == 0)
			zeroCount++;

		// Use modulus operator to determine each digit
		while (value > 0) 
		{
			digit = value % 10;

			if (digit == 0)
				zeroCount++;
			else if (digit % 2 == 0)
				evenCount++;
			else
				oddCount++;

			value = value / 10;
		}

		// Print result
		System.out.println("Zero digits: " + zeroCount);
		System.out.println("Even digits: " + evenCount);
		System.out.println("Odd digits: " + oddCount);
	}
}
