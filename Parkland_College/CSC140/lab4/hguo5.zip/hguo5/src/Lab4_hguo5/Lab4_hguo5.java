package Lab4_hguo5;

	//************************************************************
	//CSC140 Lab4.java       Author: Hu Guo
	//determines and prints the number of odd, even, 
	//and zero digits in an integer value read from the keyboard 
	//************************************************************

//Import Necessary Class
import java.util.Scanner;

public class Lab4_hguo5 {

	public static void main(String[] args) 
	{
		// Declaration and Initialization
		final int DIVISOR = 2, X = 10;
		
		long value = 0; 
		int zero = 0, even = 0, odd = 0,digit = 0,
			diviend = 0, quotient = 0, remainder = 0;
				
		String choice = "y";
		
		Scanner scan = new Scanner(System.in);
		
		//Loop to Continue the Program
		while (choice.equalsIgnoreCase("y"))
		{	
			//Input the Number as a String
			System.out.print ("Please enter an integer value: ");
			value = scan.nextLong();
			
			//Add the "\n" to Avoid Error Between 
			//nextLong() and nextLine() methods
			scan.nextLine();
			
			//Condition for Negative Number
			if(value < 0)
			{
				value *= -1;
			}
			
			//Condition for zero
			if(value == 0)
			{
				zero +=1;
			}			
			
			//Loop to Check the Value
			while (value > 0) 
			{
				//Get the Last Number Before the Decimal Place
				digit = (int) (value % X);
				
				//Remove the Last Number Before the Decimal Place
				value = value / X;
	
				//Calculation
				diviend = digit;
				quotient = diviend / DIVISOR;
				remainder = diviend % DIVISOR;
				
				//Conditions to determine zero, even and odd
				if (remainder ==0)
				{	
					if (quotient == 0)
					{
						zero++;
					}
					else
					{
						even++;
					}				
				}
				else
				{
					odd++;
				}

			}
			
			//Output the Results
			System.out.println ("Zero digits: " + zero);
			System.out.println ("Even digits: " + even);
			System.out.println (" Odd digits: " + odd);	
			
			//Reset All Counters
			zero = 0; even = 0; odd = 0;
			
			//Prompt to Continue or Quit 
			System.out.print("Input Y to continue or N to quit: ");
			
			//Input the Choice
			choice = scan.nextLine();
			
			System.out.println ("");
			
		};
		
		//Close the Object
		scan.close();
				
		//Prompt for Ending 
		System.out.println("Program terminated.");
		
	}
}
