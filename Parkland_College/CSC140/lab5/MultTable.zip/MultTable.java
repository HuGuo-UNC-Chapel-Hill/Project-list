import java.util.Scanner;

public class MultTable 
{
	public static void main(String[] args) 
	{
		// Range values
		final int MIN = 1;
		final int MAX = 12;
		
		// Scanner
		Scanner scan = new Scanner(System.in);
		
		// Prompt user for value between 1 and MAX
		int value;
		do
		{
			System.out.print("Enter an integer between " + MIN + " and " + MAX + ": ");
			value = scan.nextInt();
		}
		while( value < MIN || value > MAX);

		// For each row in the table
		for (int row = MIN; row <= value; row++) 
		{
			// For each column in the table
			for (int column = MIN; column <= value; column++)
			{
				// Compute and print row*column
				System.out.print(row * column + "\t");
			}

			// Print a new line
			System.out.println();
		}
	}
}
