package Lab5_hguo5;

//************************************************************
//CSC140 Lab5.java       Author: Hu Guo
//Output the multiplication-table 
//************************************************************


//Import Necessary Class
import java.text.DecimalFormat;

import java.util.Scanner;

public class Lab5_hguo5 
{

	public static void main(String[] args) 
	{	
		//Declaration and Initialization	
		String indent = "       ", temp="";
	
		int num = 0,iColumn = 0, iRow = 0;
		
		String choice = "y";
	
		Scanner scan = new Scanner(System.in);
		
		DecimalFormat ft = new DecimalFormat("#");
	
		while (choice.equalsIgnoreCase("y"))
		{
			//Loop to input the appropriate number
			do
			{
				System.out.print ("Enter an integer between 1 and 12: ");
				num = scan.nextInt();
			
				//Add the "\n" to Avoid Error Between 
				//nextInt() and nextLine() methods
				scan.nextLine();
			
			}while (num<1 || num>12);
		
		
			//First For Loop to output the multiplication of Column 
			for (iColumn=1; iColumn <= num; iColumn++)
			{ 	
				//Second For Loop to output the multiplication of Row
				for (iRow=1; iRow <= num; iRow++)
				{	
					//Reset Strings
					temp = "";
				
					//Assign Multiplication Result to the String
					temp = ft.format(iColumn*iRow);
				
					//Concatenate String
					temp += indent.substring(0,indent.length()-temp.length());
				
					//Output String
					System.out.print(temp);									
				
				}
				
				//Advance to theNext Row
				System.out.println ("");
			
				//Reset the Iterator 
				iRow=1;
			}
		
		
			//Prompt to Continue or Quit 
			System.out.print ("Input the 'Y' to continue or 'N' to quit: ");
			choice = scan.nextLine();
			System.out.println ("");
		}
	
		//Close the Object
		scan.close();
					
		//Prompt for Ending 
		System.out.println("Program terminated.");
	}
}