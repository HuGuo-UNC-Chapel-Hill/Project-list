
public class Flight {

	// Class fields (instance variables)
	private String name;
	private int number;
	private String origin;
	private String destination;
	
	
	// Class methods
	// Constructor
	public Flight(String n, int num, String orig, String dest)
	{
		name = n;
		number = num;
		origin = orig;
		destination = dest;
	}

	//  Returns a string representation of this flight
	public String toString() {
		return name + " " + number + ", from " + origin + " to " + destination;
	}

	// Getters (accessors) and Setters (mutators)
	public String getName() {
		return name;
	}

	public void setName(String n) {
		name = n;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int num) {
		number = num;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String orig) {
		origin = orig;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String dest) {
		destination = dest;
	}
}
