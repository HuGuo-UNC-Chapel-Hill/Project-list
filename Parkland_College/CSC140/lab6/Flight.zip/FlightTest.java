public class FlightTest {

	public static void main(String[] args) {

		// Create some Flight objects
		Flight f1 = new Flight("US Air", 347, "Boston", "Los Angeles");
		Flight f2 = new Flight("Delta", 212, "Philadelphia", "London");
		Flight f3 = new Flight("Continental", 822, "Atlanta", "Chicago");

		// Print each Flight object
		System.out.println(f1);
		System.out.println(f2);
		System.out.println(f3);
	}
}
