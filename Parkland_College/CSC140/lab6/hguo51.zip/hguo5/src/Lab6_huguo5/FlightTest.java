package Lab6_huguo5;

//************************************************************
//CSC140 Lab6.java       Author: Hu Guo
//Flight drive class 
//************************************************************

//import necessary classes
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class FlightTest {

	public static void main(String[] args) 
	{	
		////Declaration and Initialization
		final int ALPHABET = 26, objSize = 5, NUMBER = 10000;
		
		int index = 0;
		
		String abbreviation = "", choice = "Y";
		
		Scanner scan = new Scanner (System.in);
		
		DecimalFormat fmt = new DecimalFormat("0000");
		
		Random generator = new Random();
		
		//Add ten companies name to the String ArrayList name
		String[] array1 = {"United Airlines", "Spirit Airlines", "Southwest Airlines",
						   "Hawaiian Airlines", "Frontier Airlines","Delta Air Lines",
						   "American Airlines", "Alaska Airlines","JetBlue Airways",
						   "Allegiant Air"};
		ArrayList<String> name = new ArrayList<>(Arrays.asList(array1));
		
		//Add ten cities name to the String ArrayList original cities
		String[] array2 = {"New York","Los Angeles","Chicago","Miami",
						  "Dallas","Philadelphia","Houston","Atlanta",
						  "Washington","Boston"};
		ArrayList<String> origCity = new ArrayList<>(Arrays.asList(array2));
		
		//Add ten cities name to the String ArrayList destination
		String[] array3 = {"Phoenix","Seattle","San Francisco","Detroit",
						   "San Diego","Minneapolis","Tampa","Denver",
						   "Las Vegas","Portland"};
		ArrayList<String> destination = new ArrayList<>(Arrays.asList(array3));
		
		//Create the ArrayList to store objects of Flight class
		ArrayList<Flight> flights = new ArrayList<Flight>();
		
		//Loop to run the program
		do{
			//Loop to instantiates,updates objects in the ArrayList
			for(index = 0 ;index < objSize; index++)
			{				
				//Add one object to the ArrayList
				flights.add(new Flight());
				
				//Abbreviation of airlines' number
				abbreviation = "";
				abbreviation+=(char)(generator.nextInt(ALPHABET)+'A');
				abbreviation+=(char)(generator.nextInt(ALPHABET)+'A');
				
				//Updates the object in the ArrayList
				flights.get(index).setName(name.get(generator.nextInt(name.size())));
				flights.get(index).setNumber(abbreviation 
											 + fmt.format(generator.nextInt(NUMBER)));
				flights.get(index).setOrig(origCity.get(generator.nextInt(origCity.size())));
				flights.get(index).setDest(destination.get(generator.nextInt(destination.size())));										
						
			}
					
			//Loop to output objects in the ArrayList
			for (index = 0; index < flights.size(); index++)
			{
				//Output the object by toString method
				System.out.println(flights.get(index).toString());
			}
					
			//Clear the flights ArrayList
			flights.clear();
					
			//debug
			//System.out.println(flights.size());
					
			//Prompt to Continue or Quit 
			System.out.print ("Input the Y to continue or N to quit: ");
			choice = scan.nextLine();
			System.out.println ("");			
			
		}while (choice.equalsIgnoreCase("y"));
		
		//Close the Object
		scan.close();
								
		//Prompt for Ending 
		System.out.println("Program terminated.");
	}
}
