package Lab6_huguo5;

//************************************************************
//CSC140 Lab6.java       Author: Hu Guo
//Flight class 
//************************************************************

public class Flight {
	
	//Declaration of private variables
	private String name, number, origCity, destCity;
	
	//Constructor
	Flight()
	{
		name = "";
		number = "";
		origCity = "";
		destCity = "";
	}
	
	//Getters
	public String getName()
	{
		return name;
	}
	public String getNumber()
	{
		return number;
	}
	public String getOrig()
	{
		return origCity;
	}
	public String getDest()
	{
		return destCity;
	}
		
	//Setters
	public void setName(String str)
	{
		name = str;
	}
	public void setNumber(String str)
	{
		number = str;
	}
	public void setOrig(String str)
	{
		origCity = str;
	}
	public void setDest(String str)
	{
		destCity = str;
	}	
	
	//toString method
	public String toString()
	{
		String output;
		output = this.getName() + ", "  + this.getNumber() 
				+ ", from " + this.getOrig()
				+ " to " + this.getDest() +".";
		return output;
	}
}
