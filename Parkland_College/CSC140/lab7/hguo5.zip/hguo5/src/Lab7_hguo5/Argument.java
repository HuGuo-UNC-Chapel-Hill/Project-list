package Lab7_hguo5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

//class to generate random parameters
public class Argument {
	
	private static final int BASESCORE = 80, ADDSCORE = 21, MAX = 10000;
			 
	private  Random generator = new Random();	
	
	String[] array1 = {"Brian","Toyah ","Marsha", "Rayan", "Alyx", "Rayan" };
	ArrayList<String> first = new ArrayList<>(Arrays.asList(array1));
		
	String[] array2 = {"Sadler","Sadler","Sheldon","Rosa","Vance","Cano"};
	ArrayList<String> last = new ArrayList<>(Arrays.asList(array2));
	
	String[] array3 = {"325 Rafe Lane","2440 Pyramid Valley Road",
			   		   "3865 Scheuvront Drive", "958 Garfield Road",
			   		   "3249 Liberty Avenue", "2897 Hedge Street"};
	ArrayList<String> street = new ArrayList<>(Arrays.asList(array3));
	
	String[] array4 = {"Champaign","Springfield","Bloomongton",
					   "Beardstwon","Decatur","Mahomet",};
	ArrayList<String> town = new ArrayList<>(Arrays.asList(array4));
	
	String[] array5 = {"VA", "IL", "NY","CA", "TX","WA"};
	ArrayList<String> state = new ArrayList<>(Arrays.asList(array5));
		
		
	public String firstN()
	{
		return first.get(generator.nextInt(first.size()));
	}
		
	public String lastN()
	{
		return last.get(generator.nextInt(last.size()));
	}
		
	public String streets()
	{
		return street.get(generator.nextInt(street.size()));
	}
		
	public String towns()
	{
		return town.get(generator.nextInt(town.size()));
	}
		
	public String states()
	{
		return state.get(generator.nextInt(state.size()));
	}
		
	public int zip()
	{
		return (generator.nextInt(9)+ 1)* MAX + generator.nextInt(MAX);
	}
		
	public int socres()
	{
		int scores = generator.nextInt(ADDSCORE) + BASESCORE;
		return scores;
	}
}
