package Lab7_hguo5;

public class Student {
	
	private String firstName, lastName;
	private Address homeAddress, schoolAddress;
	private int test1, test2, test3, grade;
	public static final int TESTS = 3;
	
	// Old Constructor
	public Student(String first, String last, Address home,Address school)
	{
		firstName = first;
		lastName = last;
		homeAddress = home;
		schoolAddress = school;
		test1 = 0;
		test2 = 0;
		test3 = 0;
	}
	
	//Second Constructor
	public Student(String first, String last, Address home,Address school,
					int socres1, int socres2, int socres3)
	{
		firstName = first;
		lastName = last;
		homeAddress = home;
		schoolAddress = school;
		test1 = socres1;
		test2 = socres2;
		test3 =	socres3;
	}
	
	//Setter for Test Score
	public void setTestScore(int test, int socres)
	{
		if (test == 1)
		{
			test1 = socres;
		}
		if (test == 2)
		{
			test2 = socres;
		}
		else 
		{
			test3 = socres;
		}
	}
	
	//Getter for Test Score
	public int getTestScore(int test)
	{
		if (test == 1)
		{
			return test1;
		}
		if (test == 2)
		{
			return test2;
		}
		else 
		{
			return test3;
		}
	}
	
	//Calculate the average score and return it
	public int average()
	{
		grade = (test1 +test2 +test3)/TESTS;
		return grade;
	}
	
	//Getter for Name
	public String getName()
	{
		return firstName + " " + lastName;
	}
		
	//toString method to output the object
	public String toString()
	{
		String result;
		result = firstName + " " + lastName + "\n";
		result += "Home Address:\n" + homeAddress + "\n";
		result += "School Address:\n" + schoolAddress + "\n";
		result += "Test1 scores: " + test1 + "; "
				  + "Test2 scores: " + test2 + "; "
				  + "Test3 scores: " + test3 + "\n";
		result += "Average scores: " + this.average();
		return result;
	}
}

