package Lab7_hguo5;


import java.util.Scanner;

//********************************************************************
//CSC140 Lab7.java       Author: Hu Guo
//
//Demonstrates the use of an aggregate class.
//********************************************************************
public class StudentBody
{
	
	public static void main(String[] args)
	{	
		
		//Declaration and Initialization
		final int EXAM1 = 1,  EXAM2= 2, EXAM3 =3;
		
		String choice = "Y";
		
		Scanner scan = new Scanner (System.in);
		
		//Create an objobjArguuect the pass random parameters
		Argument objArgu = new Argument();
		
		//Loop to running the program
		do
		{   
			//Instantiate the object of Address class
			Address school = new Address("800 Lancaster Ave.","Villanova", "PA", 19085);
			Address jHome = new Address("21 Jump Street", "Blacksburg", "VA", 24551);
			
			//Using the new constructor to instantiate the first student
			Student john = new Student("John", "Smith", jHome, school,
										objArgu.socres(), objArgu.socres(), objArgu.socres());
			
			//Using toString method to output
			System.out.println(john);			
			System.out.println();
			
			//Instantiate the object of Address class
			Address mHome = new Address(objArgu.streets(), objArgu.towns(), 
										objArgu.states(), objArgu.zip());
			
			//Using the old constructor to instantiate the second student
			Student anyone = new Student(objArgu.firstN(), objArgu.lastN(), mHome, school);
			
			//Using setTestScore method to set scores
			anyone.setTestScore(EXAM1,objArgu.socres());
			anyone.setTestScore(EXAM2,objArgu.socres());
			anyone.setTestScore(EXAM3,objArgu.socres());
			
			//Using getters to output the second student
			System.out.println(anyone.getName() + "\n"
							 + "Home Address:\n" + mHome + "\n"
							 + "School Address:\n" +  school + "\n"
							 + "Test1 scores: " + anyone.getTestScore(EXAM1) + "; "
							 + "Test2 scores: " + anyone.getTestScore(EXAM2) + "; " 
							 + "Test3 scores: " + anyone.getTestScore(EXAM3) + "\n"
				             + "Average scores: " + anyone.average() + "\n");
			
			//Prompt to Continue or Quit 
			System.out.print ("Input 'Y' to continue or 'N' to quit: ");
			choice = scan.nextLine();
			System.out.println ("");	
			
		}while (choice.equalsIgnoreCase("y"));
		
		//Close the object
		scan.close();
										
		//Prompt for Ending 
		System.out.println("Program terminated.");
	}
}