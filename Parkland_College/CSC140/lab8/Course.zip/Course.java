
import java.util.ArrayList;

public class Course {
	
	private String courseName;
	private ArrayList<Student> studentList;

	// -----------------------------------------------------------------
	// Sets up a Course object with the specified name.
	// -----------------------------------------------------------------
	public Course(String courseNameInit) {
		courseName = courseNameInit;

		studentList = new ArrayList<Student>();
	}

	// -----------------------------------------------------------------
	// Adds a student to the course.
	// -----------------------------------------------------------------
	public void addStudent(Student newStudent) {
		studentList.add(newStudent);
	}

	// -----------------------------------------------------------------
	// Returns the average of all student test scores.
	// -----------------------------------------------------------------
	public double average() {
		double averageSum = 0.0, average = 0.0;

		for (Student student : studentList)
			averageSum += student.average();

		if (studentList.size() > 0)
			average = averageSum / studentList.size();

		return average;
	}

	// -----------------------------------------------------------------
	// Prints out all students in the course.
	// -----------------------------------------------------------------
	public void roll() {
		System.out.println(courseName + " Class Roll");

		for (Student student : studentList)
			System.out.println(student);
	}
}