import java.text.DecimalFormat;

public class Driver {
	// -----------------------------------------------------------------
	// Creates and exercises a Course object.
	// -----------------------------------------------------------------
	public static void main(String[] args) {
		
		// Create course object
		Course csc140 = new Course("Computer Science I w/ Java");

		// Create address objects
		Address school = new Address("Placeholder", "Reno", "NV", 89501);
		Address home = new Address("Placeholder", "Atlanta", "GA", 30301);

		// Create student objects
		Student john = new Student("John", "Smith", home, school, 75, 88, 78);
		Student marsha = new Student("Marsha", "Jones", home, school, 100, 98, 94);
		Student jose = new Student("Jose", "Garcia", home, school, 79, 85, 96);
		Student kayla = new Student("Kayla", "Lewis", home, school, 96, 98, 94);
		Student tanya = new Student("Tanya", "Dubinski", home, school, 89, 86, 85);

		// Add students to course
		csc140.addStudent(john);
		csc140.addStudent(marsha);
		csc140.addStudent(jose);
		csc140.addStudent(kayla);
		csc140.addStudent(tanya);

		// Print roster
		csc140.roll();

		// Print test score average
		DecimalFormat formatter = new DecimalFormat("0.0#");
		System.out.println("Average test score for all tests: "
				+ formatter.format(csc140.average()));
	}
}