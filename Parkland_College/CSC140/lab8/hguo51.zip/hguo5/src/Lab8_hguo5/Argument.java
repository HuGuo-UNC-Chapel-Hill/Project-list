package Lab8_hguo5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

//class to generate random parameters
public class Argument 
{
	
	private static final int BASESCORE = 70, ADDSCORE = 31;
			 
	private  Random generator = new Random();	
	
	String[] array1 = {"Brian","Toyah ","Marsha", "Rayan", "Alyx", 
									"Rayan", "Forbes","Talon","Angela", "Kelly " };
	ArrayList<String> first = new ArrayList<>(Arrays.asList(array1));
		
	String[] array2 = {"Sadler","Sadler","Sheldon","Rosa","Vance",
									"Cano", "Percival","Martine","Yaroslava","Eclair "};
	ArrayList<String> last = new ArrayList<>(Arrays.asList(array2));
			
	public String firstN()
	{
		return first.get(generator.nextInt(first.size()));
	}
		
	public String lastN()
	{
		return last.get(generator.nextInt(last.size()));
	}
		
	public int socres()
	{
		int scores = generator.nextInt(ADDSCORE) + BASESCORE;
		return scores;
	}
}
