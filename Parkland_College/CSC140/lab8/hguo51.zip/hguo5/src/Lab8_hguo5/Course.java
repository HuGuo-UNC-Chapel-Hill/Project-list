package Lab8_hguo5;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Course {
	
	private String name;
	private double grade = 0.0;
	private DecimalFormat formatter = new DecimalFormat("0.0#");
	
	private ArrayList<Student> students; 
	
	//Constructor only accept one String parameter
	public Course(String n)
	{
		name = n;
		students = new ArrayList<Student>();
	}
	
	//Method to add Student
	public void addStudent(Student s)
	{
		students.add(s);
	}
	
	
	//Calculate average score and return it
	public double average()
	{	
		
		for (Student s: students)
		{
			grade += s.average();
		}
		grade /= (double)students.size();
		return grade;
	}
	
	
	//Output the class list
	public void roll()
	{	
		System.out.print( name +" Class list: \n");
		for (Student s: students)
		{
			System.out.print(" " + s.getName());
			System.out.print("\n");
		}
		System.out.println();
	}
	
	//Method to return specific Student object
	public Student getStudent(int i)
	{
		return students.get(i);
	}
	
	
	//Clear all Student's objects
	public void clear()
	{	
		students.clear();
		grade = 0;
	}
	
	//ToString method to output the total number of students
	//and average score of the whole class
	public String toString()
	{
		String result;
		result = "For " + students.size() + " students in " + name 
				   + " course, overall test scores is: " + formatter.format(this.average()) +".\n";
		return result;
	}
}
