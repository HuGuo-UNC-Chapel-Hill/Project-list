package Lab8_hguo5;

//********************************************************************
//CSC140 Lab8.java       Author: Hu Guo
//
//Demonstrates the use of an aggregate class.
//********************************************************************

import java.util.Scanner;

import Lab8_hguo5.Student;

public class DriverClass {

	public static void main(String[] args) {
		//Declaration and Initialization
		final int MAX = 5;
		int i = 0;
		String choice = "Y";
		
		Scanner scan = new Scanner (System.in);
		
		Argument objArgu = new Argument();
		
		//Create an object for Course class
		Course bio101 = new Course("\"BIO 101\"");
		
		//Loop to run the program
		do
		{	
			//prompt for students detail
			System.out.println("Students' detial in this coures:");
			
			//Loop to add Student object to Course Class
			//and output details of students' object
			for(i = 0; i< MAX; i++)
			{
				bio101.addStudent(new Student(objArgu.firstN(), objArgu.lastN(),
																			objArgu.socres(), objArgu.socres(), objArgu.socres()));
				System.out.println(bio101.getStudent(i));
			}
			
			System.out.println();
			
			//Output the class list
			bio101.roll();			
			
			//Output the total number of Student's objects
			//and average score of the whole course
			System.out.println(bio101);
			
			//Clear the Student's objects
			bio101.clear();
			
			//Prompt to Continue or Quit 
			System.out.print ("Input 'Y' to continue or 'N' to quit: ");
			choice = scan.nextLine();
			System.out.println ("");	
			
		} while (choice.equalsIgnoreCase("y"));
		
		//Close the object
		scan.close();
												
		//Prompt for Ending 
		System.out.println("Program terminated.");
		
	}

}
