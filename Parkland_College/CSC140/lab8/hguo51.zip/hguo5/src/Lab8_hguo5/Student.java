package Lab8_hguo5;

import java.text.DecimalFormat;

public class Student {
	
	private String firstName, lastName;
	private int test1, test2, test3;
	private double grade;
	public static final int TESTS = 3;
	private DecimalFormat formatter = new DecimalFormat("0.0#");

	//Constructor
	public Student(String first, String last,  int socres1, int socres2, int socres3)
	{
		firstName = first;
		lastName = last;
		test1 = socres1;
		test2 = socres2;
		test3 = socres3;
	}
	
	//Setter for Test Score
	public void setTestScore(int test, int socres)
	{
			if (test == 1)
			{
				test1 = socres;
			}
			if (test == 2)
			{
				test2 = socres;
			}
			else 
			{
				test3 = socres;
			}
	}
	
	//Getter for Test Score
	public int getTestScore(int test)
	{
		if (test == 1)
		{
			return test1;
		}
		if (test == 2)
		{
			return test2;
		}
		else 
		{
			return test3;
		}
	}
	
	//Calculate the average score and return it
	public double average()
	{
		grade = (double)(test1 +test2 +test3)/TESTS;
		return grade;
	}
	
	//Getter for Name
	public String getName()
	{
		return firstName + " " + lastName;
	}
		
	//toString method to output the object
	public String toString()
	{
		String result;
		result = firstName + " " + lastName + "\n";
		result += "test1 score: " + test1 + "; "
				  	  + "test2 score: " + test2 + "; "
				      + "test3 score: " + test3 + ". ";
		result += this.getName() + "'s average score: " + formatter.format(this.average()) +".";
		return result;
	}
}

