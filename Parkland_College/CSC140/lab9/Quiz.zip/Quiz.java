import java.util.Scanner;

public class Quiz 
{
	// Class fields
	private final int MAX_QUESTIONS = 25;	// Maximum number of questions constant
	private Question[] questions;			// An array of questions
	private int current;					// Current question (and amount)
	private int correct, incorrect;

	
	// Class methods
	// Constructor
	public Quiz() 
	{
		// Create an array of 25 questions
		questions = new Question[MAX_QUESTIONS];
		
		// Current question
		current = 0;
		
		// Initialize results
		correct = incorrect = 0;
	}

	// Adds the specified question to this quiz
	public void add(Question newQuestion) 
	{
		// If less than the maximum number of questions
		if (current < MAX_QUESTIONS)
		{
			// Add the question and increment the current counter
			questions[current++] = newQuestion;
		}
	}

	// Administers this quiz
	public void giveQuiz() 
	{
		// Scanner for getting user answer
		Scanner scan = new Scanner(System.in);

		// For each question up to the current amount
		for (int i = 0; i < current; i++) 
		{
			// Print question
			System.out.println(questions[i].getQuestion());
			
			// Get answer
			if (questions[i].answerCorrect(scan.nextLine()))
			{
				// Increment correct counter
				correct++;
			}
			else
			{
				// Increment incorrect counter
				incorrect++;
			}
		}
	}

	// Returns the number of correct answers
	public int getNumCorrect() 
	{
		return correct;
	}

	// Returns the number of incorrect answers
	public int getNumIncorrect() 
	{
		return incorrect;
	}
}
