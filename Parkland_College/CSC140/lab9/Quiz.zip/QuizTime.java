
public class QuizTime 
{
	public static void main(String[] args) 
	{
		// Create a quiz
		Quiz q = new Quiz();

		// Create questions with answers
		q.add( new Question("What color was George Washington's white horse?", "white") );
		q.add( new Question("What's your favorite programming language?", "Java") );
		q.add( new Question("How many moons does the planet Earth have (specify a number)?", "1") );

		// Give the quiz
		q.giveQuiz();

		// Print quiz results
		System.out.print("\nCorrect: " + q.getNumCorrect());
		System.out.println("\tIncorrect: " + q.getNumIncorrect());
	}
}