package Lab9_hguo5;

//********************************************************************
//CSC140 Lab9.java       Author: Hu Guo
//
//Demonstrates the use of an aggregate class.
//Create a simple quiz and output the results
//********************************************************************

public class QuizTime {

	public static void main(String[] args) 
	{	
		//Create the object of Quiz Class
		Quiz quiz = new Quiz();
			
		//Create the sample quiz with 3 questions
		quiz.addQuestion(new Question("1x1=?", "1"));
		quiz.addQuestion(new Question("2+0=?", "2"));
		quiz.addQuestion(new Question("4-1=?", "3"));
		
		//Give the quiz 
		quiz.giveQuiz();
		
		//Output the result for the quiz
		System.out.println(quiz);
		System.out.println("Program terminated.");
		System.out.println();
		
		/*debugging
		//Demonstration for the max size of the quiz
		quiz.clearQuiz();
		for(int i = 0; i < 30; ++i)
		{	
			System.out.println("Current size of the quiz " +quiz.getSize());
			quiz.addQuestion(new Question("test" , "test" ));
		}
		//*/
	}
}
