package Lab9_hguo5;

import java.util.ArrayList;
import java.util.Scanner;

public class Quiz
{
	//Max size of the Quiz object
	private static final int MAX = 25;
	
	//Results of the Quiz
	private int correct = 0, incorrect = 0;
	
	//Create the ArrayList for objects of Question Class 
	private ArrayList<Question> questions;
	
	//Share Static variables to all objects
	private static Scanner scan = new Scanner(System.in);
	private static String answer ="";
	
	//Constructor
	public Quiz()
	{	
		//Max up questions to 25
		questions = new ArrayList<Question>(MAX);
		
		correct = 0;	
		incorrect = 0;
	}
	
	//AddQuestion method and check the size 
	//of the ArrayList at the same time
	public void addQuestion(Question q)
	{
		if (questions.size() < MAX)
		{
			questions.add(q);
		}
		else
		{
			System.out.println("The quiz currently has 25 questions"
											+ " and cannot be added more questions.");
		}		
	}
	
	//GiveQuiz method to present the quiz
	public void giveQuiz()
	{	
		
		for (Question q : questions)
		{
			System.out.println(q.getQuestion());
			
			answer = scan.nextLine();
			
			if (q.answerCorrect(answer))
			{	
				System.out.println("Correct");
				correct++;
			}		
			else
			{
				System.out.println("No, the answer is " + q.getAnswer());
				incorrect++;
			}
			System.out.println();
		}
	}
	
	//getSize method to return current size of the object
	public int getSize()
	{
		return questions.size();
	}
	
	public void clearGrade()
	{
		correct = 0;
		incorrect = 0;
	}
	
	//ClearQuiz method to clear the ArrayList
	public void clearQuiz()
	{
		questions.clear();
		clearGrade();
	}
	
	
	//toString method to output the results
	public String toString()
	{
		String result;
		result = "Correct:" + correct +"   " +"Incorrect: " + incorrect;
		return result;
	}
}
