package Lab9_hguo5;

import java.util.Scanner;

//********************************************************************
//CSC140 Lab9.java       Author: Hu Guo
//
//Demonstrates the use of an aggregate class.
//Create a simple quiz and output the results
//********************************************************************

public class QuizTime {

	public static void main(String[] args) 
	{	
		//Declaration and Initiation
		String choice = "Y";
		
		Scanner scan = new Scanner (System.in);
		
		//Create the object of Quiz Class
		Quiz quiz = new Quiz();
			
		//Create the sample quiz with 3 questions
		quiz.addQuestion(new Question("1x1=?", "1"));
		quiz.addQuestion(new Question("2+0=?", "2"));
		quiz.addQuestion(new Question("4-1=?", "3"));
		
		do
		{
			System.out.println("Start the quiz with three questions.\n");
			
			//Give the quiz 
			quiz.giveQuiz();
			
			//Output the result for the quiz
			System.out.println(quiz);
		
			//clear current grades
			quiz.clearGrade();
			
			//Prompt to Continue or Quit 
			System.out.print ("Input 'Y' to do it again or 'N' to quit: ");
			choice = scan.nextLine();
			System.out.println ("");	
			
		}while (choice.equalsIgnoreCase("y"));
		
		//Clear Quiz
		quiz.clearQuiz();
		
		//Close the object
		scan.close();
												
		//Prompt for Ending 
		System.out.println("Program terminated.");
		
		/*debugging
		//Demonstration for the max size of the quiz
		quiz.clearQuiz();
		for(int i = 0; i < 30; ++i)
		{	
			System.out.println("Current size of the quiz " +quiz.getSize());
			quiz.addQuestion(new Question("test" , "test" ));
		}
		//*/
	}
}
